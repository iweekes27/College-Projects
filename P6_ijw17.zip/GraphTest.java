/**
 *  Testing class for Graph.java. 
 *  Importantly, since many of the internal features and structures
 *  of the Graph class are hidden, there is no meaningful way to 
 *  test for the functionality of the add, remove, etc. functions. 
 *  Moreover, since the ordering of the nodes and their neighbors 
 *  is unknown, there is no way to test the BFS and DFS functions
 *  unless there is a single path between two nodes (not a very
 *  general test case). They have been included nonetheless. 
 */ 

import java.util.ArrayList; 
import java.util.List; 

import static org.junit.jupiter.api.Assertions.*; 
import org.junit.jupiter.api.Test; 

public class GraphTest {
    @Test 
    public void testGraphDFS() {
        // creates a linear graph of 11 nodes: 
        // 0 - 1 - ... - 10
        Graph<Integer, Integer> g = new Graph(); 
        for(int i = 0; i < 10; i++) 
            g.addEdge(i, i + 1); 

        // run DFS to get a path from 2 to 7. 
        // should return the path 2 - 3 - ... - 7
        List<Integer> path = g.DFS(2, 7); 
        for(int i = 0; i < path.size(); i++) 
            assertEquals(path.get(i), i + 2); 
    }

    @Test
    public void testGraphBFS() {
        // creates a circular graph with 6 nodes: 
        // 0 - 1 - 2 - 3 - 4 - 5 - 0
        // (both zeroes are the same on either side)
        Graph<Integer, Integer> g = new Graph(); 
        for(int i = 0; i < 6; i++) 
            g.addEdge(i, (i + 1) % 6); 

        // run BFS between nodes 2 and 4. there are two paths,
        // and it should return the shorter of the two 
        // 2 - 3 - 4 
        // 2 - 1 - 0 - 5 - 4
        List<Integer> path = g.BFS(2, 4); 
        int[] expected = {2, 3, 4}; 
        assertEquals(path.size(), expected.length); 
        for(int i = 0; i < path.size(); i++)
            assertEquals(expected[i], path.get(i)); 
    }

    @Test
    public void testGraphEmptyPath() {
        // testing DFS and BFS on a graph with no path between a pair of 
        // points. the graph will be a disconnected set of 5 points. 
        Graph<Integer, Integer> g = new Graph(); 
        for(int i = 0; i < 5; i++)
            g.addNode(i, 0); 

        List<Integer> path = g.DFS(1, 3); 
        assertTrue(path.isEmpty()); 

        path = g.BFS(1, 3); 
        assertTrue(path.isEmpty()); 
    }

    @Test
    public void testGraphNonexistentNode() {
        // testing DFS and BFS on a graph where the source and
        // target nodes do not exist in the graph. this should return
        // an empty list. 
        Graph<Integer, Integer> g = new Graph(); 
        for(int i = 0; i < 5; i++) 
            g.addNode(i, 0); 

        List<Integer> path = g.DFS(7, 19); 
        assertTrue(path.isEmpty()); 

        path = g.BFS(7, 19); 
        assertTrue(path.isEmpty()); 
    }
}
