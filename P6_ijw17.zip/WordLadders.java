import java.util.HashMap; 
import java.util.List;
import java.util.Scanner; 
import java.io.File; 
import java.io.FileNotFoundException; 

public class WordLadders {
    // main method that drives the function 
    public static void main(String[] args) {
        // prompts the user through stdin forr an input file 
        System.out.print("Please enter the word file: "); 
        Scanner input = new Scanner(System.in); 
        String wordFile = input.nextLine(); 

        // parse the file. if the graph is null, the file doesn't
        // exist. 
        Graph<Integer, String> graph = readWordGraph(wordFile); 
        if(graph == null) {
            System.out.printf("Error opening %s, exiting!\n", wordFile); 
            return; 
        }

        HashMap<Integer, String> pairs = graph.getPairs(); 

        // ask the user for two words, a start and end. 
        System.out.print("Please enter the starting word: "); 
        String start = input.nextLine(); 

        System.out.print("Please enter the ending word: "); 
        String end = input.nextLine(); 

        // find their corresponding keys 
        int startKey = -1, endKey = -1; 
        for(int key : pairs.keySet()) {
            if(pairs.get(key).equals(start)) 
                startKey = key; 

            if(pairs.get(key).equals(end)) 
                endKey = key; 
        }

        // ask the user if they want DFS or BFS 
        System.out.print("DFS (1) or BFS (2)? "); 
        int choice = input.nextInt(); 
        while(choice != 1 && choice != 2) {
            System.out.print("DFS (1) or BFS (2)? "); 
            choice = input.nextInt(); 
        }

        // perform the corresponding operation and print the results
        List<Integer> path = null; 
        if(choice == 1) path = graph.DFS(startKey, endKey); 
        else path = graph.BFS(startKey, endKey); 

        for(int i : path) 
            System.out.println(pairs.get(i)); 
    } 

    // reads a word list from the provided filename. returns null
    // if the file was not found. 
    public static Graph<Integer, String> readWordGraph(String filename) {
        Scanner input = null; 

        try {
            input = new Scanner(new File(filename)); 
        } catch(FileNotFoundException e) {
            return null; 
        }

        Graph<Integer, String> g = new Graph<Integer, String>(); 
        while(input.hasNextInt()) {
            int name = input.nextInt(); 
            String word = input.next(); 

            // reads the next line, then splits it at every space. 
            // then, it converts them all to integers. 
            String[] temp = input.nextLine().split("\\s"); 
            Integer[] neighbors = new Integer[temp.length - 1]; 
            for(int i = 1; i < temp.length; i++) 
                neighbors[i - 1] = Integer.parseInt(temp[i]); 

            // add the name/word pair to the graph, then add all of
            // the neighbors. 
            g.addNode(name, word); 
            g.addEdges(name, neighbors); 
        }

        return g; 
    }
}
