import java.util.ArrayList; 
import java.util.HashMap; 
import java.util.List; 
import java.util.LinkedList; 
import java.util.Map; 
import java.util.Scanner; 
import java.io.File; 
import java.io.FileNotFoundException; 
import java.lang.IllegalArgumentException; 

public class Graph<K, V> {
    // the data of a single node on a graph is as follows: it contains
    // the node's name itself (of type K), the associated data (of 
    // type V), and its adjacency list (of type List<Node>). 
    private class Node {
        K name; 
        V value; 
        List<Node> neighbors; 

        // constructor that takes a name and its data, with the 
        // data having a default value of null. 
        public Node(K name, V data) {
            this.name = name; 
            this.value = data; 
            neighbors = new ArrayList<Node>(); 
        }

        public Node(K name) {
            this(name, null); 
        }

        // adds a neighbor to the adjacency list, but ignores 
        // duplicates. Does not allow 1-cycles. 
        public void addNeighbor(Node neighbor) {
            if(name.equals(neighbor.name)) 
                return; 

            for(Node n : neighbors) 
                if(n.name.equals(neighbor.name)) 
                    return; 

            neighbors.add(neighbor); 
        }

        // removes a neighbor from the adjacency list. Does nothing
        // if the neighbor is not found. 
        public void removeNeighbor(K neighbor) {
            for(int i = 0; i < neighbors.size(); i++) {
                Node n = neighbors.get(i); 
                if(n.name.equals(neighbor)) {
                    neighbors.remove(i); 
                    return; 
                }
            }
        }
    }

    // this is the internal map of nodes in the graph, which associates
    // the names with the actual nodes themselves. 
    private Map<K, Node> graph; 

    // default constructor, initialises to an empty graph 
    public Graph() {
        graph = new HashMap<K, Node>(); 
    }

    // adds a name-data pair, representing a node, to the graph. 
    // if the name already exists in the graph, then its value is 
    // simply overwritten. this always returns true. 
    public boolean addNode(K name, V value) {
        Node n = graph.get(name); 

        // make a new node if it's not in there already. 
        if(n == null) 
            graph.put(name, new Node(name, value)); 
        else 
            n.value = value; 
        
        return true; 
    }

    // adds an entire array of name-data pairs to the graph. 
    // if any of their names are already in the graph, their values
    // are overwritten. If there are any duplicates in the input, 
    // only the value with the greatest index is kept. always returns
    // true. throws an IllegalArgumentException if the arrays have
    // mismatched lengths.
    public boolean addNodes(K[] names, V[] values) {
        if(names.length != values.length) 
            throw new IllegalArgumentException(); 

        for(int i = 0; i < names.length; i++) 
            addNode(names[i], values[i]); 

        return true; 
    }

    // adds an undirected edge between the provided nodes. 
    // If either node is not already in the graph, they are 
    // added to the graph with a null value. Always returns true. 
    public boolean addEdge(K from, K to) {
        Node fromNode = graph.get(from); 
        Node toNode = graph.get(to); 

        // add new nodes if either is null, or both.
        if(fromNode == null) {
            fromNode = new Node(from); 
            graph.put(from, fromNode); 
        }

        if(toNode == null) {
            toNode = new Node(to); 
            graph.put(to, toNode); 
        }

        toNode.addNeighbor(fromNode); 
        fromNode.addNeighbor(toNode); 
        return true; 
    }

    // adds edges between the provided from node to each element of 
    // toList. If any node is not already present in the graph, it 
    // is added with a null value. 
    public boolean addEdges(K from, K... toList) {
        // search for a fromNode exactly once. we should avoid calling
        // addEdge for each toList since this will force us to search
        // for the fromNode every time. 
        Node fromNode = graph.get(from); 

        if(fromNode == null) {
            fromNode = new Node(from); 
            graph.put(from, fromNode); 
        }

        // now for each toNode, do the following: 
        // 1. search for it in the graph
        // 2. add it to the graph if it's not there.
        // 3. make an edge between the two. 
        for(K to : toList) {
            Node toNode = graph.get(to); 
            if(toNode == null) {
                toNode = new Node(to); 
                graph.put(to, toNode); 
            }

            toNode.addNeighbor(fromNode); 
            fromNode.addNeighbor(toNode); 
        }

        return true; 
    }

    // removes a node from the graph and deletes all of its connected 
    // edges from the remaining graph. returns true if a node was 
    // deleted and returns false if no such node exists. 
    public boolean removeNode(K name) {
        Node removal = graph.get(name);

        // node not found 
        if(removal == null) 
            return false; 

        // node found - delete it from the graph, then go through
        // its neighbors and delete the corresponding edges. 
        graph.remove(name); 
        for(Node n : removal.neighbors) 
            n.removeNeighbor(name); 

        return true; 
    }

    // removes each node in the list from the graph. returns true if 
    // any node was removed, false if none of the nodes were found
    // in the graph. 
    public boolean removeNodes(K... nodeList) {
        boolean success = false; 
        for(K name : nodeList) 
            success = success || removeNode(name); 

        return success; 
    }

    // prints the graph to the screen, as specified in the 
    // instructions. No ordering is guaranteed on the adjacency list
    // or the list of nodes. 
    public void printGraph() {
        for(Node source : graph.values()) {
            // printing node 
            System.out.printf("%s", source.name); 

            // printing neighbors 
            for(Node neighbor : source.neighbors) 
                System.out.printf(" %s", neighbor.name); 

            System.out.println(); 
        }
    }

    // reads a graph from the provided file name and constructs a 
    // Graph<String, V> out of it. Each node will have a value of null.
    // returns null if the file was not found. 
    static <V> Graph<String, V> read(String filename) {
        Scanner input = null; 
        try {
            input = new Scanner(new File(filename)); 
        } catch(FileNotFoundException e) {
            return null; 
        }

        Graph<String, V> g = new Graph<String, V>(); 

        while(input.hasNext()) {
            // reads the next line, then splits it along the 
            // whitespace. this produces line[0] as the node and the
            // rest as its neighbors. Note graph will skip the self-
            // edge resulting from the addEdges call. 
            String[] line = input.nextLine().split("\\s"); 
            g.addEdges(line[0], line); 
        }

        return g; 
    }

    // implementation of DFS. this returns an array of names that 
    // represents the path taken from the source to the target. 
    // returns an empty array if no such path exists. 
    // NOTE: the return type was changed from K[] to List<K> since
    // java does not permit declarations of generic arrays. 
    public List<K> DFS(K from, K to) {
        // first, look for the from node. 
        Node fromNode = graph.get(from);

        // if there's no node for this name, return an empty array
        if(fromNode == null) 
            return new ArrayList<K>(); 

        LinkedList<K> visited = new LinkedList<K>(); 
        List<K> path = DFS(fromNode, to, visited);
        
        // null path means that there is no path between the 
        // provided from and to nodes
        if(path == null) 
        	path = new ArrayList<K>(); 
        return path; 
    }

    private List<K> DFS(Node current, K target, LinkedList<K> visited) {
        // if this node has been visited, exit immediately.
        if(visited.contains(current.name)) 
            return null; 

        visited.push(current.name); 

        // if the current node is the target, we're done. 
        if(current.name.equals(target)) {
            LinkedList<K> path = new LinkedList<K>(); 
            path.add(current.name); 
            return path; 
        }

        // recursively call DFS on the children.
        for(Node next : current.neighbors) {
            List<K> path = DFS(next, target, visited); 

            // if the path is not null, we found the target. 
            if(path != null) {
                path.add(0, current.name); 
                return path; 
            }
        }

        // otherwise, this node is a dead end.
        return null; 
    }
        
    // implementation of BFS. this returns an array of names that 
    // represents the path taken from the source to the target. 
    // returns an empty array if no such path exists. 
    // NOTE: the return type was changed from K[] to List<K> since
    // java does not permit declarations of generic arrays. 
    public List<K> BFS(K from, K to) {
        // first, look for the from node. 
        Node fromNode = graph.get(from);

        // if there's no node for this name, return an empty array
        if(fromNode == null) 
            return new ArrayList<K>(); 

        // create a hash map representing the previous node in the
        // path to the target. 
        HashMap<K, K> previous = new HashMap<K, K>(); 

        // now populate the previous list using BFS. Note we will be
        // using explore as a queue. 
        LinkedList<K> visited = new LinkedList<K>(); 
        LinkedList<Node> explore = new LinkedList<Node>(); 
        explore.add(fromNode); 

        while(!explore.isEmpty()) {
            Node current = explore.poll(); 
            visited.add(current.name); 

            // if we've found the target, we have all the info we 
            // really need. 
            if(current.name.equals(to)) break; 

            // for each neighbor that has not already been visited, 
            // add it to the explore queue and update its previous
            // node as the current node. 
            for(Node next : current.neighbors) {
                // skip visited nodes 
                if(visited.contains(next.name)) 
                    continue; 

                explore.add(next); 

                // if this is the first time we reach the child, 
                // add this connection to the previous map. 
                if(previous.get(next.name) == null)
                    previous.put(next.name, current.name); 
            }
        }

        // we have now populated our previous map. build the path
        // using its data. 
        List<K> path = new LinkedList<K>(); 
        if(previous.get(to) == null) 
            return path; 

        K currName = to; 
        while(currName != null) {
            path.add(0, currName); 
            currName = previous.get(currName); 
        }

        return path; 
    }

    // additional helper function that returns a hash map of all of 
    // the name-data pairs present in the graph. 
    public HashMap<K, V> getPairs() {
        HashMap<K, V> pairs = new HashMap<K, V>(); 
        for(Node n : graph.values()) 
            pairs.put(n.name, n.value); 
        return pairs; 
    }
}
