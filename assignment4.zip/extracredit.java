import java.util.ArrayList;
import java.util.NoSuchElementException;

 class PriorityQueue<K extends Comparable<? super K>, V> {
    // TODO: Implement the PriorityQueue class using a max-heap

    public PriorityQueue() {
        // TODO: Implement the constructor
    }

    public PriorityQueue(K[] keys, V[] values) throws IllegalArgumentException {
        // TODO: Implement the constructor
    }

    public void add(K key, V value) {
        // TODO: Implement the add method
    }

    public void update(K key, V value) throws NoSuchElementException {
        // TODO: Implement the update method
    }

    public V peek() {
        // TODO: Implement the peek method
    }

    public V[] peek(int k) {
        // TODO: Implement the peek(int k) method
    }

    public V poll() throws NoSuchElementException {
        // TODO: Implement the poll method
    }

    public K poll(V value) throws NoSuchElementException {
        // TODO: Implement the poll(V value) method
    }

    public int size() {
        // TODO: Implement the size method
    }
}



 public class CMDbGroup {
    // TODO: Implement the CMDbGroup class
    public static void main(String[] args) {
 
    }


    public CMDbGroup() {
        // TODO: Implement the constructor
    }

    public static HashTable<CMDbProfile> registeredUsers() {
        // TODO: Implement the registeredUsers method
    }

    public String[] group() {
        // TODO: Implement the group method
    }

    public void addMember(CMDbProfile member) {
        // TODO: Implement the addMember method
    }

    public void addMember(CMDbProfile[] members) {
        // TODO: Implement the addMember(CMDbProfile[] members) method
    }

    public static String favorite(String userName) {
        // TODO: Implement the favorite(String userName) method
    }

    public String[] groupFavorites() {
        // TODO: Implement the groupFavorites method
    }

    public String randomMovie(int k) {
        // TODO: Implement the randomMovie(int k) method
    }


}

public class CMDbProfile {
    // TODO: Implement the CMDbProfile class

    public CMDbProfile(String userName) {
        // TODO: Implement the constructor
    }

    public void changeUserName(String userName) {
        // TODO: Implement the changeUserName method
    }

    public boolean rate(String movie, int rating) {
        // TODO: Implement the rate method
    }

    public boolean changeRating(String movie, int newRating) {
        // TODO: Implement the changeRating method
    }

    public boolean removeRating(String movie) {
        // TODO: Implement the removeRating method
    }

    public String[] favorite() {
        // TODO: Implement the favorite method
    }

    public String[] favorite(int k) {
        // TODO: Implement the favorite(int k) method
    }

    public String profileInformation() {
        // TODO: Implement the profileInformation method
    }

    public boolean equals(Object o) {
        // TODO: Implement the equals method
    }
}
