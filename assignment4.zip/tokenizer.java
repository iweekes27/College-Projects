import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class Tokenizer {
    private ArrayList<String> words;
    
    // Constructor for processing a file
    public Tokenizer(String file) {
        words = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                processLine(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Constructor for processing a string array
    public Tokenizer(String[] text) {
        words = new ArrayList<>();
        for (String line : text) {
            processLine(line);
        }
    }

    // Processes a line of text and adds words to the words list
    private void processLine(String line) {
        String[] tokens = line.split("\\s+");
        for (String token : tokens) {
            words.add(normalize(token));
        }
    }

    // Returns the normalized version of a word
    private String normalize(String word) {
        return word.toLowerCase().replaceAll("\\W", "");
    }

    // Returns the list of words
    public ArrayList<String> wordList() {
        return words;
    }
    public static void main(String[] args) {
 
    }
}
  