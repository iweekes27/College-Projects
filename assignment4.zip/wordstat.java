import java.util.ArrayList;
import java.util.Collections;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class WordStat {
    private HashTable<Integer> wordFrequencyTable;
    private ArrayList<String> sortedWords;
    private ArrayList<String> words;

    public WordStat(String file) {
        words = readWordsFromFile(file);
        processWords(words);
    }

    public WordStat(String[] text) {
        words = new ArrayList<>(Arrays.asList(text));
        processWords(words);
    }

    // Reads words from file and returns an ArrayList
    private ArrayList<String> readWordsFromFile(String file) {
        ArrayList<String> words = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split("\\s+");
                Collections.addAll(words, tokens);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return words;
    }

    // Processes words and populates the wordFrequencyTable and sortedWords
    private void processWords(ArrayList<String> words) {
        wordFrequencyTable = new HashTable<>();
        for (String word : words) {
            wordFrequencyTable.put(word, 1);
        }
        sortedWords = new ArrayList<>(wordFrequencyTable.size());
        for (String word : words) {
            if (!sortedWords.contains(word)) {
                sortedWords.add(word);
            }
        }
        Collections.sort(sortedWords, (w1, w2) -> wordFrequencyTable.get(w2) - wordFrequencyTable.get(w1));
    }

    public int wordCount(String word) {
        return wordFrequencyTable.get(word);
    }

    public int wordRank(String word) {
        return sortedWords.indexOf(word) + 1;
    }

    public String[] mostCommonWords(int k) {
        if (k < 0) {
            throw new IllegalArgumentException("k must be non-negative.");
        }
        String[] mostCommon = new String[Math.min(k, sortedWords.size())];
        for (int i = 0; i < mostCommon.length; i++) {
            mostCommon[i] = sortedWords.get(i);
        }
        return mostCommon;
    }

    public String[] leastCommonWords(int k) {
        if (k < 0) {
            throw new IllegalArgumentException("k must be non-negative.");
        }
        String[] leastCommon = new String[Math.min(k, sortedWords.size())];
        for (int i = 0; i < leastCommon.length; i++) {
            leastCommon[i] = sortedWords.get(sortedWords.size() - i - 1);
        }
        return leastCommon;
    }

    public String[] mostCommonCollocations(int k, String baseWord, boolean precede) {
    if (k < 0 || !sortedWords.contains(baseWord)) {
        throw new IllegalArgumentException("k must be non-negative and baseWord must exist in the text.");
    }
    HashTable<Integer> collocationsTable = new HashTable<>();
    for (int i = 0; i < words.size(); i++) {
        if (words.get(i).equals(baseWord)) {
            if (precede && i > 0) {
                collocationsTable.put(words.get(i - 1), 1);
            } else if (!precede && i < words.size() - 1) {
                collocationsTable.put(words.get(i + 1), 1);
            }
        }
    }
    ArrayList<String> sortedCollocations = new ArrayList<>(collocationsTable.size());
    for (String word : words) {
        if (!sortedCollocations.contains(word) && collocationsTable.get(word) != null) {
            sortedCollocations.add(word);
        }
    }
    Collections.sort(sortedCollocations, (w1, w2) -> collocationsTable.get(w2) - collocationsTable.get(w1));
    String[] mostCommonCollocations = new String[Math.min(k, sortedCollocations.size())];
    for (int i = 0; i < mostCommonCollocations.length; i++) {
        mostCommonCollocations[i] = sortedCollocations.get(i);
    }
    return mostCommonCollocations;
    }
}