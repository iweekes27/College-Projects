import java.util.ArrayList;
import java.util.NoSuchElementException;

public class HashTable<T> {
    private ArrayList<ArrayList<Entry>> table;
    private int size;

    // Default constructor
    public HashTable() {
        this(10);
    }

    // Constructor with specified capacity
    public HashTable(int capacity) {
        if (capacity < 1) {
            throw new IllegalArgumentException("Capacity must be a positive integer.");
        }
        table = new ArrayList<>(capacity);
        for (int i = 0; i < capacity; i++) {
            table.add(new ArrayList<>());
        }
        size = 0;
    }

    // Get the value associated with a key
    public T get(String key) {
        int index = hash(key);
        for (Entry entry : table.get(index)) {
            if (entry.key.equals(key)) {
                return entry.value;
            }
        }
        throw new NoSuchElementException("Key not found.");
    }

    // Store a key-value pair
    public void put(String key, T value) {
        int index = hash(key);
        ArrayList<Entry> list = table.get(index);
        for (Entry entry : list) {
            if (entry.key.equals(key)) {
                if (value instanceof Integer && entry.value instanceof Integer) {
                    entry.value = (T) Integer.valueOf(((Integer) entry.value) + ((Integer) value));
                } else {
                    entry.value = value;
                }
                return;
            }
        }
        list.add(new Entry(key, value));
        size++;
        if ((float) size / table.size() >= 1) {
            rehash();
        }
    }

    // Remove a key-value pair
    public T remove(String key) {
        int index = hash(key);
        ArrayList<Entry> list = table.get(index);
        for (int i = 0; i < list.size(); i++) {
            Entry entry = list.get(i);
            if (entry.key.equals(key)) {
                list.remove(i);
                size--;
                return entry.value;
            }
        }
        throw new NoSuchElementException("Key not found.");
    }

    // Get the number of elements in the hash table
    public int size() {
        return size;
    }

    // Calculate the hash value for a key
    private int hash(String key) {
        return Math.abs(key.hashCode()) % table.size();
    }

    // Rehash the table when the load factor threshold is reached
    private void rehash() {
        ArrayList<ArrayList<Entry>> oldTable = table;
        int newCapacity = oldTable.size() * 2;
        table = new ArrayList<>(newCapacity);
        for (int i = 0; i < newCapacity; i++) {
            table.add(new ArrayList<>());
        }
        size = 0;
        for (ArrayList<Entry> list : oldTable) {
            for (Entry entry : list) {
                put(entry.key, entry.value);
            }
        }
    }

    // Entry class to store key-value pairs
    private class Entry {
        String key;
        T value;

        public Entry(String key, T value) {
            this.key = key;
            this.value = value;
        }
    }
}