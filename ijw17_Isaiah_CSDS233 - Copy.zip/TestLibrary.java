import org.junit.Test; 
import static org.junit.Assert.*; 

public class TestLibrary {
    @Test 
    public void testBookConstructor() {
        // this should work with no exceptions
        new Book("Title", "0123456789012", "Author"); 
    } 

    @Test(expected = IllegalArgumentException.class) 
    public void testBadIsbnLength() {
        new Book("Title", "0123", "Author"); 
    } 

    @Test(expected = IllegalArgumentException.class) 
    public void testBadIsbnLetters() {
        new Book("Title", "abcdefghijklm", "Author"); 
    } 

    @Test
    public void testTitle() {
        Book b = new Book("Title", "0123456789012", "Author"); 
        assertEquals(b.getTitle(), "Title"); 
    } 

    @Test
    public void testISBN() {
        Book b = new Book("Title", "0123456789012", "Author"); 
        assertEquals(b.getISBN(), "0123456789012"); 
    }

    @Test
    public void testAuthor() {
        Book b = new Book("Title", "0123456789012", "Author"); 
        assertEquals(b.getAuthor(), "Author"); 
    }

    @Test
    public void testLibraryConstructor() {
        new LibraryDatabase(100); 
    } 

    @Test
    public void testLibraryZeroCapacity() {
        new LibraryDatabase(0);
    }

    @Test(expected = IllegalArgumentException.class) 
    public void testLibraryNegativeCapacity() {
        new LibraryDatabase(-100); 
    } 

    @Test
    public void testAddingBooks() {
        // these books are sorted by ISBN right now. we'll add them
        // in reverse order and see if it comes out the same. 
        Book[] books = {
            new Book("Generic Book", "0000000000001", "First Last"), 
            new Book("Generic Book", "0000000000002", "First Last"), 
            new Book("Generic Book", "0000000000003", "First Last"), 
            new Book("Generic Book", "0000000000004", "First Last"), 
            new Book("Generic Book", "0000000000005", "First Last"), 
            new Book("Generic Book", "0000000000006", "First Last"), 
            new Book("Generic Book", "0000000000007", "First Last"), 
            new Book("Generic Book", "0000000000008", "First Last"), 
            new Book("Generic Book", "0000000000009", "First Last"), 
            new Book("Generic Book", "0000000000010", "First Last"), 
        }; 

        LibraryDatabase l = new LibraryDatabase(100); 
        for(int i = books.length - 1; i >= 0; i--) 
            l.add(books[i]); 

        // now check that the books are in the right order 
        for(int i = 0; i < books.length; i++) 
            assertEquals(books[i].getISBN(), l.toArray()[i].getISBN()); 
    } 

    @Test 
    public void testAddingBooksLowCapacity() {
        // exactly the same as testAddingBooks, but with a lower initial capacity. 
        Book[] books = {
            new Book("Generic Book", "0000000000001", "First Last"), 
            new Book("Generic Book", "0000000000002", "First Last"), 
            new Book("Generic Book", "0000000000003", "First Last"), 
            new Book("Generic Book", "0000000000004", "First Last"), 
            new Book("Generic Book", "0000000000005", "First Last"), 
            new Book("Generic Book", "0000000000006", "First Last"), 
            new Book("Generic Book", "0000000000007", "First Last"), 
            new Book("Generic Book", "0000000000008", "First Last"), 
            new Book("Generic Book", "0000000000009", "First Last"), 
            new Book("Generic Book", "0000000000010", "First Last"), 
        }; 

        LibraryDatabase l = new LibraryDatabase(100); 
        for(int i = books.length - 1; i >= 0; i--) 
            l.add(books[i]); 

        for(int i = 0; i < books.length; i++) 
            assertEquals(books[i].getISBN(), l.toArray()[i].getISBN());        
    }
} 
