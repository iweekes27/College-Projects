public class LibraryDatabase {
    private Book[] books; 
    private int numBooks; 

    public LibraryDatabase(int capacity) {
        // make sure capacity is nonnegative 
        if(capacity < 0) 
            throw new IllegalArgumentException("Capacity of LibraryDatabase cannot be negative."); 

        books = new Book[capacity]; 
        numBooks = 0; 
    } 

    // private helper function to expand capacity. 
    // this increases the capacity by 10 books every time it's 
    // called, and it copies over all of the old books into
    // the new array. 
    private void expandCapacity() {
        Book[] oldBooks = books; 
        books = new Book[books.length + 10]; 

        // copy all of the old books into the front of the new book array
        for(int i = 0; i < oldBooks.length; i++) 
            books[i] = oldBooks[i]; 
    }

    public void add(Book book) {
        // expand capacity of the database if there's no space for the new book 
        if(numBooks + 1 >= books.length) 
            expandCapacity(); 


        // perform a linear search for where we should insert the book. 
        // books[newIndex]'s ISBN should come AFTER the new book's ISBN, 
        // so as long as book[newIndex]'s ISBN comes before, we need to 
        // increment the new index, or stop if we're at the end of the array.
        int newIndex = 0; 
        String newISBN = book.getISBN(); 
        while(newIndex < numBooks) {
            // if the current index book has a later ISBN than the new book,
            // exit this while loop. 
            String currISBN  = books[newIndex].getISBN(); 
            if(currISBN.compareTo(newISBN) > 0) break; 

            // otherwise, move the current index forward 
            newIndex += 1; 
        } 

        // increment the number of books, then shift everything after the new
        // index down by one in the array. Finally, add the new book at the
        // requested index. 
        numBooks += 1; 
        for(int i = numBooks - 1; i > newIndex; i--) 
            books[i] = books[i - 1]; 
        books[newIndex] = book; 
    } 

    public Book remove(String isbn) {
        // perform a linear search for the isbn provided. 
        int targetIndex = 0; 
        while(targetIndex < numBooks) {
            int compare = isbn.compareTo(books[targetIndex].getISBN()); 

            // if the isbn at the target index is equal to 
            // the requested book, eureka! 
            if(compare == 0) break; 

            // if the isbn is bigger, then we've gone too far. 
            else if(compare > 0) return null; 

            // otherwise, keep looking 
            targetIndex++; 
        } 

        // if the target index is equal to the number of books, we didn't 
        // find the isbn anywhere. 
        if(targetIndex == numBooks) return null; 

        // now remember the book at the current index, then move everything
        // to the right of it down one index. 
        Book removed = books[targetIndex]; 
        for(int i = targetIndex; i < numBooks - 1; i++)
            books[i] = books[i + 1]; 

        // replace the last index with null and decrease the number of books 
        numBooks -= 1; 
        books[numBooks] = null; 
        return removed; 
    } 

    public int size() {
        return numBooks; 
    } 

    public Book randomSelection() {
        // if there are no books, return null
        if(numBooks == 0) return null; 

        int index = (int)(Math.random() * numBooks); 
        return books[index]; 
    } 

    public Book findByTitle(String title) {
        // since the books are not sorted by title, we just have to 
        // check each book one by one and return it if the title matches. 
        for(int i = 0; i < numBooks; i++) 
            if(books[i].getTitle().equals(title)) 
                return books[i]; 

        // if we finished the for loop, no books matched the title 
        return null; 
    } 

    public Book findByISBN(String isbn) {
        // perform a binary search! if there are no books though, 
        // we can immediately return null 
        if(numBooks == 0) return null; 

        // start and end represent the index bounds (inclusive). 
        // every iteration, compute the midpoint, and compare the isbn.
        // * if the isbn is smaller, then set start = mid + 1. 
        // * if the isbn is bigger, then set end = mid - 1. 
        // * if they match, we found our book. 
        // if ever start > end, then we couldn't find the book. 
        int start = 0, end = numBooks - 1; 
        while(start <= end) {
            int mid = (start + end) / 2; 
            int compare = books[mid].getISBN().compareTo(isbn); 

            // perfect match
            if(compare == 0) return books[mid]; 

            // mid isbn is too small 
            else if(compare < 0) start = mid + 1; 

            // mid isbn is too large 
            else end = mid - 1; 
        } 

        // if we're out here, we didn't find the book 
        return null; 
    } 

    public Book[] getAllByAuthor(String author) {
        // first, count how many books the author wrote
        int booksWritten = 0; 
        for(int i = 0; i < numBooks; i++) 
            if(books[i].getAuthor().equals(author))
                booksWritten += 1; 

        // now create an empty array of books 
        Book[] authorsBooks = new Book[booksWritten]; 

        // loop over the books again, and copy the books by the 
        // author into the empty array. 
        int authorIndex = 0; 
        for(int i = 0; i < numBooks; i++) {
            if(books[i].getAuthor().equals(author)) {
                authorsBooks[authorIndex] = books[i]; 
                authorIndex += 1; 
            }
        }

        return authorsBooks; 
    }

    public void removeDuplicates() {
        // the algorithm is as follows: 
        // have a slow and a fast counter, both initialised to zero. 
        // while the fast counter is smaller than numBooks - 1, do the following: 
        // 1. increment the fast counter. 
        // 2. check if the isbn of the fast counter is equal to the isbn of the 
        //    slow counter. If they are equal, there is a duplicate; go back to
        //    the top of the loop. 
        // 3. If the isbn's aren't equal, increment the slow counter, then copy the
        //    book in the fast counter into the slow counter. 
        int slow = 0, fast = 0; 
        while(fast < numBooks - 1) {
            fast += 1; 

            // ISBN is a duplicate - repeat the loop 
            if(books[fast].getISBN().equals(books[slow].getISBN())) 
                continue; 

            // increment slow, then copy. 
            slow += 1; 
            books[slow] = books[fast]; 
        } 

        // now slow is the last index with a unique book; we need to clear out the
        // rest of the books and update the number of books 
        for(int i = slow + 1; i < numBooks; i++) 
            books[i] = null; 

        numBooks = slow + 1; 
    }

    public Book[] toArray() {
        return books; 
    }
} 
