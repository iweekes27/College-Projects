public class Book {
    private String title, isbn, author; 

    public Book(String title, String isbn, String author) {
        // verify that the isbn is 13 characters long 
        if(isbn.length() != 13) 
            throw new IllegalArgumentException("The ISBN number " + isbn + "is invalid."); 

        // check that each character is between 0 and 9 
        for(int i = 0; i < isbn.length(); i++) 
            if(isbn.charAt(i) < '0' || isbn.charAt(i) > '9') 
                throw new IllegalArgumentException("The ISBN number " + isbn + "is invalid."); 

        this.title = title; 
        this.isbn = isbn; 
        this.author = author; 
    }

    // accessors 
    public String getTitle() {
        return title; 
    } 

    public String getISBN() {
        return isbn; 
    } 

    public String getAuthor() {
        return author; 
    } 
}
