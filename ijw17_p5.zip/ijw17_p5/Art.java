public class Art {
    // private variables - these keep track of the data associated
    // to a piece of art. 
    private int height, width;
    private int price; 
    private String name, artistName; 

    // constructs a piece of art with the provided height, price, 
    // width, name, and artist, in that order. 
    public Art(int height, int price, int width, String name, 
               String artistName) {
        this.height = height; 
        this.price = price; 
        this.width = width; 
        this.name = name; 
        this.artistName = artistName; 
    }

    // getters and setters for each of the private fields.
    public int getHeight() { 
        return height; 
    }

    public int getPrice() {
        return price; 
    }

    public int getWidth() {
        return width; 
    } 

    public String getName() {
        return name; 
    } 

    public String getArtistName() {
        return artistName; 

    } 

    public void setHeight(int height) {
        this.height = height; 
    }

    public void setPrice(int price) {
        this.price = price; 
    }

    public void setWidth(int width) {
        this.width = width; 
    } 

    public void setName(String name) {
        this.name = name; 
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName; 
    }
}
