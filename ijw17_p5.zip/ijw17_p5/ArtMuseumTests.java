import java.util.ArrayList; 
import java.util.List; 

import static org.junit.jupiter.api.Assertions.*; 
import org.junit.jupiter.api.Test;

public class ArtMuseumTests {
    @Test
    public void testArtClass() {
        // create an art object first, check all getters work. 
        Art art = new Art(10, 100, 30, "Mona Laura", "Leo Vince"); 
        assertEquals(art.getHeight(), 10); 
        assertEquals(art.getWidth(), 30); 
        assertEquals(art.getPrice(), 100); 
        assertEquals(art.getName(), "Mona Laura"); 
        assertEquals(art.getArtistName(), "Leo Vince"); 

        // now check that the setters change the values. 
        art.setHeight(45); 
        assertEquals(art.getHeight(), 45); 

        art.setWidth(9); 
        assertEquals(art.getWidth(), 9); 

        art.setPrice(1000); 
        assertEquals(art.getPrice(), 1000); 

        art.setName("Mona Laurel"); 
        assertEquals(art.getName(), "Mona Laurel"); 

        art.setArtistName("Leo da Vince"); 
        assertEquals(art.getArtistName(), "Leo da Vince"); 
    }

    @Test
    public void testAddArtMuseum() {
    	// add should never return false, even over the course
    	// of 10000 calls.
    	ArtMuseum museum = new ArtMuseum("The Metropolitan"); 
    	for(int i = 0; i < 10000; i++) {
    		assertTrue(museum.add(new Art(10, 30, 50, "Art", "Artist"))); 
    	}
    }
    
    @Test
    public void testFindArts() {
    	// create an array of artwork to add. only one of them is
    	// by quentin tarantino 
    	Art[] art = {
    		new Art(10, 20, 30, "Feet", "Quentin Tarantino"), 
    		new Art(30, 10, 40, "Sunflowers", "Miles Morales"), 
    		new Art(50, 90, 10, "Good", "Will Hunting")
    	};
    	
    	ArtMuseum museum = new ArtMuseum("Movie Gallery");
    	for(Art a : art) {
    		museum.add(a); // tested in previous test
    	}
    	
    	List<Art> found = museum.findArts("Quentin Tarantino"); 
    	assertEquals(found.size(), 1); 
    	assertEquals(found.get(0).getArtistName(), "Quentin Tarantino"); 
    	assertEquals(found.get(0).getName(), "Feet"); 
    	
    	// test searching for an artist that's not in the museum
    	found = museum.findArts("Brad Pitt"); 
    	assertTrue(found.isEmpty());
    }
    
    @Test
    public void testRandomizeArts() {
    	// create an array of artwork to add. they all have 
    	// different heights.
    	Art[] art = {
    		new Art(1, 0, 0, "Art", "Artist1"), 
    		new Art(2, 0, 0, "Art", "Artist2"), 
    		new Art(3, 0, 0, "Art", "Artist3"), 
    		new Art(4, 0, 0, "Art", "Artist4"), 
    		new Art(5, 0, 0, "Art", "Artist5"), 
    		new Art(6, 0, 0, "Art", "Artist6"), 
    		new Art(7, 0, 0, "Art", "Artist7")
    	}; 
    	
    	// add them all to the museum 
    	ArtMuseum museum = new ArtMuseum("Pawn Shop"); 
    	for(Art a : art) {
    		museum.add(a); 
    	}
    	
    	// get a randomized list that should be empty. 
    	List<Art> randomList = museum.randomizeArts(0); 
    	assertTrue(randomList.isEmpty()); 
    	
    	randomList = museum.randomizeArts(-50); 
    	assertTrue(randomList.isEmpty());
    	
    	// try getting a list of 6 artworks 
    	randomList = museum.randomizeArts(6); 
    	assertEquals(randomList.size(), 6); 
    	
    	// we can't really do any testing on the contents 
    	// of randomList, as it should be random. 
    }
    
    @Test
    public void testSort() {
    	// create an array of art to sort by height 
    	// in decreasing order. 
    	Art[] art = {
			new Art(10, 0, 0, "Apple", ""), 
			new Art(1, 0, 0, "Banana", ""), 
			new Art(5, 0, 0, "Cranberry", ""), 
			new Art(19, 0, 0, "Date", ""), 
			new Art(7, 0, 0, "Elderberry", ""), 
			new Art(41, 0, 0, "Fruit", "")
    	}; 
    	
    	// list of art names in the right order
    	String[] names = {
    		"Banana", "Cranberry", "Elderberry", "Apple", "Date", "Fruit"
    	}; 
    	
    	// make a museum, add all the artwork, then check that
    	// the sorted list is in the right order. 
    	ArtMuseum m = new ArtMuseum("Supermarket"); 
    	for(Art a : art) {
    		m.add(a); 
    	}
    	
    	List<Art> sorted = m.sort("height", 1); 
    	assertEquals(sorted.size(), names.length);
    	for(int i = 0; i < sorted.size(); i++) {
    		assertEquals(sorted.get(i).getName(), names[i]); 
    	}
    	
    	// now sort in descending order of artwork name. 
    	names = new String[] {
    		"Fruit", "Elderberry", "Date", "Cranberry", "Banana", "Apple"
    	}; 
    	
    	sorted = m.sort("names", -1); 
    	assertEquals(sorted.size(), names.length);
    	for(int i = 0; i < sorted.size(); i++) {
    		assertEquals(sorted.get(i).getName(), names[i]); 
    	}
    }
    
    @Test
    public void testRandomSort() {
    	// create a list of artwork in such a way that we know
    	// the right order after it gets sorted.
    	List<Art> list = new ArrayList<Art>(); 
    	list.add(new Art(15, 19, 48, "A", "1")); // should not change order
    	list.add(new Art(19, 37, 11, "B", "2")); 
    	
    	list.add(new Art(11, 93, 39, "C", "3")); // change order
    	list.add(new Art(8, 14, 19, "D", "4")); 
    	
    	list.add(new Art(1, 15, 51, "E", "5")); // no change
    	list.add(new Art(399, 2, 74, "F", "6")); 
    	
    	list.add(new Art(50, 300, 94, "G", "7")); // no order
    	list.add(new Art(97, 414, 12, "H", "8")); 
    	
    	list.add(new Art(14, 404, 3, "I", "9"));  // change order: "10" is before "9"
    	list.add(new Art(39, 18, 18, "J", "10")); // as a string
    	
    	// array of artwork names, in the right order
    	String[] names = {
    		"A", "B", "D", "C", "E", "F", "G", "H", "J", "I"
    	}; 
    	
    	ArtMuseum museum = new ArtMuseum("Generic Museum"); 
    	List<Art> sorted = museum.randomSort(list); 
    	assertEquals(sorted.size(), names.length);
    	for(int i = 0; i < sorted.size(); i++) {
    		assertEquals(sorted.get(i).getName(), names[i]); 
    	}
    }
}
