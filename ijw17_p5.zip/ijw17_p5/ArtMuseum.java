import java.util.ArrayList; 
import java.util.List;

public class ArtMuseum {
	// private variables - just the name and the list of artworks
	List<Art> artwork; 
	String museumName; 
	
	// creates a new art museum with the specified name and an 
	// initially empty collection of artwork. 
	public ArtMuseum(String museumName) {
		this.museumName = museumName; 
		artwork = new ArrayList<Art>(); 
	}
	
	// adds a piece of artwork to the museum's collection. returns
	// true if the addition was successful, returns false otherwise.
	// currently, there is no way for the addition to be unsuccessful
	public boolean add(Art art) {
		artwork.add(art); 
		return true; 
	}
	
	// searches for a given artist and returns a list of all of that
	// artist's work that's in the museum's collection. if no such 
	// pieces of artwork exist, it returns an empty list. 
	public List<Art> findArts(String artistName) {
		List<Art> found = new ArrayList<Art>(); 
		
		// scan through all of the art objects. add the ones with 
		// matching artist names to the found list. 
		for(Art art : artwork) {
			if(art.getArtistName().equals(artistName)) {
				found.add(art); 
			}
		}
		
		return found; 
	}
	
	// randomly generates and returns a list of n art objects. 
	public List<Art> randomizeArts(int n) {
		// first, ensure n is positive. if it's not, return an 
		// empty list.
		List<Art> randomArt = new ArrayList<Art>(); 
		if(n <= 0) 
			return randomArt; 
		
		// now shuffle the entire list of artwork by swapping the 
		// last element in the list with a random element. 
		for(int i = artwork.size() - 1; i > 0; i--) {
			int index = (int)(Math.random() * artwork.size()); 
			Art temp = artwork.get(index); 
			artwork.set(index,  artwork.get(i));
			artwork.set(i, temp); 
		}
		
		// copy the first n items in the list into randomArt, which
		// have been randomized! 
		for(int i = 0; i < n; i++) 
			randomArt.add(artwork.get(i));
		
		return randomArt; 
	}
	
	// returns the list of artwork, sorted according to the attribute
	// and the specified direction. 
	public List<Art> sort(String attribute, int direction) {
		// create a copy of the internal list - we don't want to 
		// expose our list object to the outside. 
		List<Art> sorted = new ArrayList<Art>(); 
		for(Art art : artwork) 
			sorted.add(art); 
		
		// call our internal sorting function, then return 
		sort(sorted, 0, artwork.size(), attribute, direction); 
		return sorted; 
	}

	// provided a list of art objects, it sorts the first fifth 
	// by height, the next by price, then by width, name, and artist
	// name, all in increasing order. 
	public List<Art> randomSort(List<Art> art) {
		// create a copy of the provided list 
		List<Art> sorted = new ArrayList<Art>(); 
		for(Art a : art) 
			sorted.add(a); 
		
		// create an array of attributes. then sort each fifth of 
		// the array by the corresponding attribute, in order. 
		String[] attributes = {
			"height", "price", "width", "names", "artistName"
		}; 
		
		for(int i = 0; i < attributes.length; i++) {
			int start = sorted.size() * i / 5; 
			int end = sorted.size() * (i + 1) / 5; 
			
			// call the recursive helper. make sure the direction
			// is positive so it's in ascending order. 
			sort(sorted, start, end, attributes[i], 1); 
		}
		
		return sorted; 
	}
	
	// private helper functions for sort. first, here's a comparison 
	// helper than compares the two artworks by the specified 
	// attribute and direction. returns a negative number if the 
	// first argument comes first, a positive value if it comes
	// second, and zero if they're tied. 
	private int compareArt(Art a1, Art a2, String attr, int dir) {
		int compare = 0; 
		switch(attr) {
		case "height": 
			compare = a1.getHeight() - a2.getHeight(); 
			break; 
		case "price": 
			compare = a1.getPrice() - a2.getPrice(); 
			break;
		case "width": 
			compare = a1.getWidth() - a2.getWidth(); 
			break; 
		case "names": 
			compare = a1.getName().compareTo(a2.getName());
			break; 
		case "artistName": 
			compare = a1.getArtistName().compareTo(a2.getArtistName());
			break; 
		}
		
		// if the direction is negative, flip the ordering.
		if(dir < 0) 
			compare *= -1; 
		
		return compare; 
	}
	
	// helper function to partition the provided list of artwork 
	// between the provided endpoints, using the provided attribute
	// and direction. returns the index of the pivot. start is 
	// inclusive while end is exclusive. 
	private int partition(List<Art> l, int start, int end, 
			String attr, int dir) {
		int pivot = start; 
		for(int i = start + 1; i < end; i++) {
			int c = compareArt(l.get(pivot), l.get(i), attr, dir); 
			
			// if c <= 0, the pivot is in place. otherwise, move pivot
			// to the next spot
			if(c > 0) {
				Art temp = l.get(pivot); 
				l.set(pivot,  l.get(i)); 
				l.set(i,  l.get(pivot + 1)); 
				l.set(pivot + 1, temp); 
				pivot++; 
			}
		}
		
		return pivot; 
	}

	// recursive implementation of quicksort. 
	private void sort(List<Art> l, int start, int end, 
			String attr, int dir) {
		// this means that there is only one element to sort.
		if(end <= start + 1)
			return; 
		
		// get the pivot, then sort each side of the pivot. 
		int pivot = partition(l, start, end, attr, dir); 
		sort(l, start, pivot, attr, dir); 
		sort(l, pivot + 1, end, attr, dir); 
	}
}